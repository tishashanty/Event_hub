<?php
session_start();
// If already logged in as admin, redirect
if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'admin') {
    header('Location: admin_dashboard.php');
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'event_management');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = '';
$success = '';
$show_reset_form = false;
$reset_email = '';

// Handle password reset request
if (isset($_POST['reset_request'])) {
    $email = trim($_POST['email']);
    $reset_email = $email;
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format.';
    } else {
        // Check if admin exists with this email
        $stmt = $conn->prepare("SELECT admin_id, first_name FROM admin WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $admin = $result->fetch_assoc();
            $admin_id = $admin['admin_id'];
            
            // Generate reset token (valid for 1 hour)
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            // Delete any existing tokens for this user
            $delete_stmt = $conn->prepare("DELETE FROM password_resets WHERE user_id = ? AND user_type = 'admin'");
            $delete_stmt->bind_param('i', $admin_id);
            $delete_stmt->execute();
            $delete_stmt->close();
            
            // Store token in database
            $stmt = $conn->prepare("INSERT INTO password_resets (user_id, user_type, token, expires_at) VALUES (?, 'admin', ?, ?)");
            $stmt->bind_param('iss', $admin_id, $token, $expires);
            
            if ($stmt->execute()) {
                $success = "Password reset instructions have been sent to your email!";
                $show_reset_form = true;
                
                error_log("Reset token created for admin $admin_id: $token");
            } else {
                $error = 'Failed to generate reset token. Please try again.';
                error_log("Token insertion error: " . $stmt->error);
            }
            $stmt->close();
        } else {
            $error = 'No admin account found with this email address.';
        }
    }
}

// Handle direct password reset from login page
if (isset($_POST['direct_reset'])) {
    $email = trim($_POST['reset_email']);
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format.';
    } elseif (strlen($new_password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } elseif ($new_password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } else {
        // Check if admin exists with this email
        $stmt = $conn->prepare("SELECT admin_id FROM admin WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $admin = $result->fetch_assoc();
            $admin_id = $admin['admin_id'];
            
            // Update password directly
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update_stmt = $conn->prepare("UPDATE admin SET password = ? WHERE admin_id = ?");
            $update_stmt->bind_param('si', $hashed_password, $admin_id);
            
            if ($update_stmt->execute()) {
                $success = 'Password reset successfully! You can now login with your new password.';
                $show_reset_form = false;
                error_log("Password reset directly for admin $admin_id");
            } else {
                $error = 'Failed to reset password. Please try again.';
                error_log("Direct password reset error: " . $update_stmt->error);
            }
            $update_stmt->close();
        } else {
            $error = 'No admin account found with this email address.';
        }
        $stmt->close();
    }
}

// Handle regular login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['reset_request']) && !isset($_POST['direct_reset'])) {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $validationErrors = array();
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $validationErrors[] = 'Invalid email format.';
    }
    if ($password === '') {
        $validationErrors[] = 'Password is required.';
    }

    if (empty($validationErrors)) {
        $stmt = $conn->prepare("SELECT * FROM admin WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['admin_id'];
                $_SESSION['role'] = 'admin';
                $_SESSION['first_name'] = $user['first_name'];
                $_SESSION['last_name'] = $user['last_name'];
                header('Location: admin_dashboard.php');
                exit();
            } else {
                $error = 'Invalid password.';
            }
        } else {
            $error = 'Admin not found.';
        }
    } else {
        $error = implode('<br>', $validationErrors);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Event Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        .login-container { 
            max-width: 450px; 
            margin: 0 auto;
            width: 100%;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px 15px 0 0 !important;
            padding: 25px;
            text-align: center;
        }
        .card-header h3 {
            margin: 0;
            font-weight: 600;
        }
        .card-body {
            padding: 30px;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 12px;
            font-weight: 500;
        }
        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .btn-success {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            border: none;
            padding: 12px;
            font-weight: 500;
        }
        .btn-success:hover {
            transform: translateY(-1px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .form-control {
            padding: 12px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        .forgot-password {
            color: #667eea;
            text-decoration: none;
            font-size: 0.9rem;
        }
        .forgot-password:hover {
            color: #764ba2;
            text-decoration: underline;
        }
        .reset-success {
            background-color: #d1fae5;
            border: 1px solid #a7f3d0;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .reset-form {
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 20px;
            margin-top: 20px;
        }
        .password-strength {
            height: 4px;
            border-radius: 2px;
            margin-top: 5px;
            transition: all 0.3s ease;
        }
        .strength-weak { background-color: #ef4444; width: 25%; }
        .strength-fair { background-color: #f59e0b; width: 50%; }
        .strength-good { background-color: #10b981; width: 75%; }
        .strength-strong { background-color: #059669; width: 100%; }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-lock me-2"></i>Admin Login</h3>
            </div>
            <div class="card-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($success && !$show_reset_form): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <!-- Login Form (Hidden when reset form is shown) -->
                <?php if (!$show_reset_form): ?>
                <form method="POST" action="" id="loginForm">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                            <input type="email" class="form-control" id="email" name="email" required 
                                   inputmode="email" autocomplete="username" 
                                   value="<?php echo isset($email) && !isset($_POST['reset_request']) ? htmlspecialchars($email, ENT_QUOTES) : ''; ?>">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control" id="password" name="password" required 
                                   autocomplete="current-password">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 mb-3">
                        <i class="fas fa-sign-in-alt me-2"></i>Login
                    </button>
                    
                    <div class="text-center">
                        <a href="#" class="forgot-password" data-bs-toggle="modal" data-bs-target="#forgotPasswordModal">
                            <i class="fas fa-key me-1"></i>Forgot Password?
                        </a>
                    </div>
                </form>
                <?php endif; ?>

                <!-- Reset Password Form (Shown after email submission) -->
                <?php if ($show_reset_form): ?>
                <div class="reset-success text-center mb-4">
                    <i class="fas fa-paper-plane fa-2x text-primary mb-3"></i>
                    <h5 class="text-success">Check Your Email!</h5>
                    <p class="mb-0">Password reset instructions have been sent to:<br>
                    <strong><?php echo htmlspecialchars($reset_email); ?></strong></p>
                </div>

                <div class="reset-form">
                    <h6 class="text-center mb-3">Or reset your password directly:</h6>
                    <form method="POST" action="" id="directResetForm">
                        <input type="hidden" name="reset_email" value="<?php echo htmlspecialchars($reset_email); ?>">
                        
                        <div class="mb-3">
                            <label for="new_password" class="form-label">New Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                <input type="password" class="form-control" id="new_password" name="new_password" required 
                                       minlength="6" placeholder="Enter new password">
                            </div>
                            <div class="password-strength" id="passwordStrength"></div>
                            <div class="form-text">Password must be at least 6 characters long.</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required 
                                       minlength="6" placeholder="Confirm new password">
                            </div>
                            <div id="passwordMatch" class="form-text"></div>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" name="direct_reset" class="btn btn-success">
                                <i class="fas fa-save me-2"></i>Reset Password
                            </button>
                           
                        </div>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Forgot Password Modal -->
    <div class="modal fade" id="forgotPasswordModal" tabindex="-1" aria-labelledby="forgotPasswordModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="forgotPasswordModalLabel">
                        <i class="fas fa-key me-2"></i>Reset Password
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <p>Enter your email address and we'll send you a link to reset your password.</p>
                        <div class="mb-3">
                            <label for="reset_email" class="form-label">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                <input type="email" class="form-control" id="reset_email" name="email" required 
                                       value="<?php echo isset($email) && isset($_POST['reset_request']) ? htmlspecialchars($email, ENT_QUOTES) : ''; ?>">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="reset_request" class="btn btn-primary">
                            <i class="fas fa-paper-plane me-2"></i>Send Reset Link
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-show modal if there was a reset request error
        <?php if (isset($_POST['reset_request']) && $error): ?>
            document.addEventListener('DOMContentLoaded', function() {
                var modal = new bootstrap.Modal(document.getElementById('forgotPasswordModal'));
                modal.show();
            });
        <?php endif; ?>

        // Auto-focus on email field in modal when it opens
        document.getElementById('forgotPasswordModal').addEventListener('shown.bs.modal', function () {
            document.getElementById('reset_email').focus();
        });

        // Password strength indicator
        document.getElementById('new_password')?.addEventListener('input', function() {
            const password = this.value;
            const strengthBar = document.getElementById('passwordStrength');
            let strength = 0;
            
            if (password.length >= 6) strength += 25;
            if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength += 25;
            if (password.match(/\d/)) strength += 25;
            if (password.match(/[^a-zA-Z\d]/)) strength += 25;
            
            strengthBar.className = 'password-strength ';
            if (strength <= 25) strengthBar.classList.add('strength-weak');
            else if (strength <= 50) strengthBar.classList.add('strength-fair');
            else if (strength <= 75) strengthBar.classList.add('strength-good');
            else strengthBar.classList.add('strength-strong');
        });

        // Password confirmation check
        document.getElementById('confirm_password')?.addEventListener('input', function() {
            const password = document.getElementById('new_password').value;
            const confirm = this.value;
            const matchText = document.getElementById('passwordMatch');
            
            if (confirm === '') {
                matchText.textContent = '';
                matchText.className = 'form-text';
            } else if (password === confirm) {
                matchText.textContent = '✓ Passwords match';
                matchText.className = 'form-text text-success';
            } else {
                matchText.textContent = '✗ Passwords do not match';
                matchText.className = 'form-text text-danger';
            }
        });

        // Form validation
        document.getElementById('directResetForm')?.addEventListener('submit', function(e) {
            const password = document.getElementById('new_password').value;
            const confirm = document.getElementById('confirm_password').value;
            
            if (password.length < 6) {
                e.preventDefault();
                alert('Password must be at least 6 characters long.');
                return false;
            }
            
            if (password !== confirm) {
                e.preventDefault();
                alert('Passwords do not match.');
                return false;
            }
        });
    </script>
</body>
</html>